<?php
$hn = 'localhost';
$db = 'verenigingsleden';
$un = 'root';
$pw = 'FveNr8qw@jhgrFj';
